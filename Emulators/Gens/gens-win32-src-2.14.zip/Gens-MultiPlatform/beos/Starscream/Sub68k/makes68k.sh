#!/bin/sh
cd "`dirname \"$0\"`"		# for being called from Tracker
Terminal build_sub68k