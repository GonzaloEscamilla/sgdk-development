#ifndef _CPU_Z80_H
#define _CPU_Z80_H

#ifdef __cplusplus
extern "C" {
#endif

int Z80_Init(void);
void Z80_Reset(void);

#ifdef __cplusplus
};
#endif

#endif