January 28, 2005 - c0d3h4x0r@hotmail.com

This folder should be the eventual final location for the Linux port of Gens.

Whoever maintains the GensForLinux module needs to relocate it (branch it?) to live under here instead.  Then, that tree needs to be gradually merged into the ..\common folder to share platform non-specific code with the other ports of Gens.


