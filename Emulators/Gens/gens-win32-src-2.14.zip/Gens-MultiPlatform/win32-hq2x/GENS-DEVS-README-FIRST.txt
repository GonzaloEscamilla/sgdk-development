January 28, 2005 - c0d3h4x0r@hotmail.com

This folder contains just the source changes submitted by someone for adding VGM and HQ2x support to Gens for Windows.  These changes need to be applied to the ..\win32 tree, and then this tree needs to be entirely removed.

