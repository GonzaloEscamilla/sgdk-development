January 28, 2005 - c0d3h4x0r@hotmail.com

Whoever maintains this GensForLinux tree, please note:

We (Stef and I) are trying to get all the different port of Gens into a single tree structure that facilitates sharing of platform-nonspecific code, to avoid too much divergence in terms of features and bug fixes.

Please checkout the Gens-MultiPlatform module, familiarize yourself with the layout of that tree to get an understanding of the structure, and then relocate/branch this tree underneath the "linux' folder there.

Thanks!

