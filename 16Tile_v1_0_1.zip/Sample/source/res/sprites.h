#ifndef _RES_SPRITES_H_
#define _RES_SPRITES_H_

extern const SpriteDefinition spr_player;

#endif // _RES_SPRITES_H_
