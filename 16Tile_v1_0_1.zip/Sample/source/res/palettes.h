#ifndef _RES_PALETTES_H_
#define _RES_PALETTES_H_

extern const Palette pal_player;
extern const Palette pal_stage_01a;
extern const Palette pal_stage_01b;

#endif // _RES_PALETTES_H_
