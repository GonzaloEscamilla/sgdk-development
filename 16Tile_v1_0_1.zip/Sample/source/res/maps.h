#ifndef _RES_MAPS_H_
#define _RES_MAPS_H_

extern const TileSet ts_stage_01;
extern const MapDefinition map_stage_01;
extern const MapDefinition map_stage_01_bg;

#endif // _RES_MAPS_H_
